<?PHP
$e7d8519cd15377ed0c4313a338f2814a="78387d8ea7680a67ddb5a843a32b126a";

#-------------------------------------------------------------------------------------------------------------

include "autopilot_configuration.php";
include "inc/globals.php";
include "language/".$config['language'].".php";
include "inc/login_functions.php";
include "inc/client_area_functions.php";
include "inc/general_functions.php";
include "inc/order_functions.php";
include "inc/billing_functions.php";
include "inc/display_functions.php";

#-------------------------------------------------------------------------------------------------------------

if (!$c40181b59df275585740ecc344d3eb98) { die("Error[4]: Invalid file access, exiting..."); }
if (strlen($c40181b59df275585740ecc344d3eb98)!=32) { die("Error[5]: Invalid file access, exiting..."); }
if (strlen(${c40181b59df275585740ecc344d3eb98})!=32) { die("Error[6]: Invalid file access, exiting..."); }
if (strcmp($c40181b59df275585740ecc344d3eb98, "50d88f80f3f2c2329d15a78dbe59d259")!=0)
	{
	die("Error[7]: Invalid file access, exiting...");
	}

#-------------------------------------------------------------------------------------------------------------

clear_cache();
$client_id=process_session($config);
if (isset_reset_password($client_id)==1) 
	{ 
	$client_in_process=true;
	header("Location: ".$config['http_web']."/client_in_process.php");
	exit;
	}

#-------------------------------------------------------------------------------------------------------------

$order=billing_get_order_details(rg($_GET, $_POST, $_COOKIE, "order_id"));
$product=unserialize(sx($order['order_array']));

#-------------------------------------------------------------------------------------------------------------

$show_upgrades=false;
if ($order['hosting_id']&&$order['status']=='active')
	{
	$products=get_product_data($order['product_id']);
	$upgrade_array=unserialize(sx($products['upgrade_array']));
	$upgrade_array=(is_array($upgrade_array))?$upgrade_array:array();

	foreach ($upgrade_array as $upgrade)
		{;
		$upgrades=get_upgrade_details($upgrade);
		if ($upgrades['show_in']=='extras')
			{
			$upgrade_link=$config['http_web']."/browse_extras.php?order_id=".$order['order_id'];
			$show_upgrades="<input class='submit' onclick='window.location=\"".$upgrade_link."\"' type='button' value='".$w['client_view_order']['upgrade_view_options']."'> ";
			}
		}
	}

#-------------------------------------------------------------------------------------------------------------


include $config['server_tpl']."/header.php";
include $config['server_tpl']."/client_view_order.php";
include $config['server_tpl']."/footer.php";
mysql_close($dblink);
?>