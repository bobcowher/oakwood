============================
WHM AutoPilot Version 3.2.83
20th November 2012
============================

Detailed installation instructions can be
found at https://whmautopilot.com/docs/

============================
