<?PHP 
$send_to='you@yourdomain.com';

include 'autopilot_configuration.php';

function validate_ion($verify_sign)
	{
	$request="verify_sign=".$verify_sign;

	$header="POST /whmap/client/rename_upload_me/validate_ion.php HTTP/1.0\r\n";
	$header.="Content-Type: application/x-www-form-urlencoded\r\n";
	$header.="Content-Length: ".strlen($request)."\r\n\r\n";
	$fp=@fsockopen("localhost", 80, $errno, $errstr, 30);

	if ($fp) 
		{
		@fputs($fp, $header.$request);
		while (!@feof($fp))
			{
			$data=fgets($fp, 1024);
			if (@strcmp(@$data, "PASSED")==0)
				{
				return true;
				}
			}

		@fclose ($fp);
		}

	return false;
	}

function sx($var) 
	{ 
	return stripslashes(trim(html_entity_decode($var, ENT_QUOTES, "ISO-8859-15"))); 
	}

if (!validate_ion($_POST['verify_sign'])) 
	{ 
	die('Failed to validate the ION.'); 
	}

$subject="Order Details: {$_POST['client']['first_name']} {$_POST['client']['last_name']}";

$message=("Client Details: 

{$_POST['client']['first_name']} {$_POST['client']['last_name']}");

if ($_POST['client']['org']) { $message.="\nOrg: {$_POST['client']['org']}"; }
if ($_POST['client']['address']) { $message.="\n{$_POST['client']['address']}"; }
if ($_POST['client']['address_1']) { $message.="\n{$_POST['client']['address_1']}"; }
if ($_POST['client']['city']) { $message.="\n{$_POST['client']['city']}"; }
if ($_POST['client']['state']) { $message.=", {$_POST['client']['state']}"; }
if ($_POST['client']['province']) { $message.=", {$_POST['client']['province']}"; }
if ($_POST['client']['zip']) { $message.=" {$_POST['client']['zip']}"; }
if ($_POST['client']['country']) { $message.=" {$_POST['client']['country']}"; }
if ($_POST['client']['phone']) { $message.="\nPhone: {$_POST['client']['phone']}"; }
if ($_POST['client']['fax']) { $message.="\nPhone: {$_POST['client']['fax']}"; }
if ($_POST['client']['email']) { $message.="\nE-mail: {$_POST['client']['email']}"; }
if ($_POST['client']['logged_ip']) { $message.="\nLogged IP: {$_POST['client']['logged_ip']}"; }
if ($_POST['client']['logged_host']) { $message.="\nLogged Host: {$_POST['client']['logged_host']}"; }

$message.="\n\nOrder Details:\n";

foreach ($_POST['order'] as $key => $value)
	{
	$order=$value;
	$invoice=$_POST['invoice'][$key];
	$register=$_POST['register'][$key];
	$license=$_POST['license'][$key];

	$message.="\nCart ID: {$order['cart_id']}";
	$message.="\nOrder ID: {$order['order_id']}";
	$message.="\nProfile ID: {$order['profile_id']}";
	$message.="\nInvoice ID: {$invoice['invoice_id']}";
	$message.="\nClient ID: {$order['client_id']}";

	$product=mysql_fetch_assoc(mysql_query("select * from autopilot_products where product_id='{$order['product_id']}'"));
	$message.="\n\nProduct: {$product['product_name']} #{$order['product_id']}";

	if ($order['upgrade_array']) 
		{ 
		$buffer=false;
		$order['upgrade_array']=explode('{|}', $order['upgrade_array']);
		foreach ($order['upgrade_array'] as $upgrade_id)
			{
			$upgrade=mysql_fetch_assoc(mysql_query("select * from autopilot_upgrade_package where upgrade_id='{$upgrade_id}'"));
			$buffer.="\n - {$upgrade['upgrade_package_name']}"; 
			}
		
		if ($buffer) 
			{
			$message.="\nUpgrades Ordered:\n"; 
			$message.="{$buffer}\n"; 
			}
		}

	if ($order['addon_array']) 
		{ 
		$buffer=false;
		$order['addon_array']=explode('{|}', $order['addon_array']);
		foreach ($order['addon_array'] as $addon_id)
			{
			$addon=mysql_fetch_assoc(mysql_query("select * from autopilot_product_addons where addon_id='{$addon_id}'"));
			$buffer.="\n - {$addon['addon_name']}"; 
			}
		
		if ($buffer) 
			{
			$message.="\nAddons Ordered:\n"; 
			$message.="{$buffer}\n"; 
			}
		}

	if ($order['coupon_array']) 
		{
		$buffer=false;
		$order['coupon_array']=explode('{|}', $order['coupon_array']);
		foreach ($order['coupon_array'] as $coupon_code)
			{
			$buffer.="\n - {$coupon_code}"; 
			}
		
		if ($buffer) 
			{
			$message.="\nCoupons Used:\n"; 
			$message.="{$buffer}\n"; 
			}
		}

	$message.="\n\nEnd of Order ID {$order['order_id']} ------------------------------";
	}


# I will upgrade mail to the pear lib soon.

# send a nice summary of the order.
mail($send_to, $subject, $message);

/*
# e-mail to an autoresponder ------------------------------------------------------------------------------------
# You will need to fill in the details below and format it like you need it. Let me know if I can help.         
# ---------------------------------------------------------------------------------------------------------------

# The subject:
$subject="autoresponder: {$_POST['client']['first_name']} {$_POST['client']['last_name']}";

# The message
$message="{$_POST['client']['first_name']} {$_POST['client']['last_name']}, {$_POST['client']['email']}";

# who to, the subject, the message
mail($_POST['client']['email'], $subject, $message);
*/
?>