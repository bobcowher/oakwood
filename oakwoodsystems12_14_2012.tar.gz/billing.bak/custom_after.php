<?PHP
$e7d8519cd15377ed0c4313a338f2814a="78387d8ea7680a67ddb5a843a32b126a";

#-------------------------------------------------------------------------------------------------------------

include "autopilot_configuration.php";
include "inc/globals.php";
include "language/".$config['language'].".php";
include "inc/general_functions.php";
include "inc/order_functions.php";
include "inc/billing_functions.php";
include "inc/email_functions.php";
include "inc/client_functions.php";
include "inc/client_area_functions.php";
include "inc/domain_functions.php";
include "inc/whois_functions.php";
include "inc/server_functions.php";

// set charset
$charset = acb_get_charset();
header("Content-type: text/html; charset={$charset}");

#-------------------------------------------------------------------------------------------------------------

if (!$c40181b59df275585740ecc344d3eb98) { die("Error[4]: Invalid file access, exiting..."); }
if (strlen($c40181b59df275585740ecc344d3eb98)!=32) { die("Error[5]: Invalid file access, exiting..."); }
if (strlen(${c40181b59df275585740ecc344d3eb98})!=32) { die("Error[6]: Invalid file access, exiting..."); }
if (strcmp($c40181b59df275585740ecc344d3eb98, "50d88f80f3f2c2329d15a78dbe59d259")!=0)
	{
	die("Error[7]: Invalid file access, exiting...");
	}

#-------------------------------------------------------------------------------------------------------------

$cookie_domain=get_cookie_domain($config);
if ($_COOKIE['order_session']) { $session=get_session_data($_COOKIE['order_session'], $config, $w); }

if (!isset($_COOKIE['module_index_after'])&&!empty($session))
	{
	$cart_id=billing_create_cart_id_order($_COOKIE['order_session']);
	$client=get_client_details($_COOKIE['client_session']);

	// let see if we can get an email initiated

	process_addon_emails($cart_id);

	// process upgrade orders email and automations
	process_upgrade_emails($cart_id);

	#-------------------------------------------
	
	if (!x('invoice_payment')) {
	    $array['to_email']=$client['email'];
    	$array['to_name']=sx($client['first_name'])." ".sx($client['last_name']);
    	$array['config']=$config;

		$processor_specific=get_processor_specific($session['processor_key']);
		$array['payment_instructions']=$processor_specific['bankwire_instructions'];

    	# START E-MAIL HOOKS ----------------------------------------------------------------------------------------

    	# Send the new order confirmation e-mail
    	#$use_one_time=true;
    	$array['event_id']="client_new_order_confirmation";


    	imports::email_events('general');
    	imports::api('EmailEvents');

    	// get the order id, so we can get the product
    	$q = "SELECT `pro`.`ord_email` FROM `autopilot_products` AS `pro`, `autopilot_order` AS `ord` WHERE `ord`.`cart_id` = '" . a($cart_id) . "' AND `ord`.`product_id` = `pro`.`product_id` ";
    	$rs = mysql_fetch_object(mysql_query($q));

    	if ($rs->ord_email == 0) {
    	    EmailEventsApi::Send('client_new_order_confirmation', $client['email'], "{$client['firstname']} {$client['last_name']}", $array);
    	} else {
    	    $template = EmailEventsApi::getEmailById($rs->ord_email);

        	EmailEventsApi::SendByTemplate($template, $client['email'], "{$client['firstname']} {$client['last_name']}", $array);
    	}
	}

	//compile_email($array);

	# START DOMAIN REGISTRARS HOOK ------------------------------------------------------------------------------

	process_domain($cart_id);

	# DO ION
	#--------------------------------------------------------------------------------------------------------
	
	if ($config['ion'])
		{
		$cart_id=billing_create_cart_id_order($_COOKIE['order_session']);
		$id_set=get_id_set_read_only($cart_id);

		$verify_sign=make_verify_sign($config);
		write_verify_sign($verify_sign);

		$full_array=build_ion_arrays($id_set);
		$full_array['verify_sign']=$verify_sign;
		unset($client['credit_card']);
		unset($client['password']);
		$profile_array=unserialize(sx($client['profile_array']));
		$client['profile_array']=@implode('{|}', $profile_array);
		$full_array['client']=$client;
		$querystring=http_build_query($full_array);

		$ions=explode("\n", $config['ion']);
		foreach ($ions as $ion)
			{
			$ion=trim($ion);
			if (!$ion) { continue; }
			if (empty($ion)) { continue; }
		
			$parts=@parse_url($ion);

			$fp=@fsockopen($parts['host'], 80, $errno, $errstr, 10); // was 5

			if (!$fp) { continue; }

			$header="POST ".$parts['path']." HTTP/1.0\r\n";
			$header.="Host: ".$parts['host']."\r\n";
			$header.="Content-type: application/x-www-form-urlencoded\r\n";
			$header.="User-Agent: WHM.Autopilot v3 ION (http://www.whmautopilot.com)\r\n";
			$header.="Content-length: ".@strlen($querystring)."\r\n";
			$header.="Connection: close\r\n\r\n";
			$header.=$querystring;

			$data=false;
			if (function_exists('stream_set_timeout')) { @stream_set_timeout($fp, 20); }
			@fputs($fp, $header);

			if (function_exists('socket_get_status')) { $status=@socket_get_status($fp); } 
			else { $status=true; }

			while (!@feof($fp)&&$status) 
				{
				$data.=@fgets($fp, 1024);

				if (function_exists('socket_get_status')) { $status=@socket_get_status($fp); } 
				else 
					{
					if (feof($fp)==true) { $status=false; } 
					else { $status=true; }
					}
				}
			
			@fclose ($fp);
			# echo "<textarea rows='100' cols='100'>".$data."</textarea>"; die;
			}
		}
	}


$modules=client_get_all_modules();
if (!$modules)
	{
	header("Location: order_complete.php");
	exit;
	}

$modules=isolate_modules("order_after", $config['profile_id'], $modules);
if (!$modules)
	{
	header("Location: ".$config['http_web']."/order_complete.php");
	exit;
	}

if (!isset($_COOKIE['module_index_after']))
	{
	@setcookie("module_index_after", "0", (time()+31536000), "/", $cookie_domain);

	header("Location: ".$config['http_web']."/custom_after.php");
	exit;	
	}

if (!$modules[$_COOKIE['module_index_after']])
	{
	header("Location: ".$config['http_web']."/order_complete.php");
	exit;
	}

$link_out=$config['http_web'];
$link_out.="/modules/custom/";
$link_out.=$modules[$_COOKIE['module_index_after']]['module_name'];
$link_out.="/module_start.php?module_id=".$modules[$_COOKIE['module_index_after']]['module_id'];
header("Location: ".$link_out);
exit;
# print_r($modules[$_COOKIE['module_index']]);

# THIS IS THE KEY TO MOVING ONTO THE NEXT MODULE
# setcookie("module_index", ($_COOKIE['module_index']+=1), (time()+31536000), "/");
?>