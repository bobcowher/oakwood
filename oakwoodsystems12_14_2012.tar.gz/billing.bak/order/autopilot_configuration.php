<?php
$db_conf = array(
  'hostname' => 'localhost',
  'username' => 'whm_auto',
  'password' => 'Ch8fRef5',
  'database' => 'whm_auto',
);
if (! ($dblink = mysql_connect($db_conf['hostname'], $db_conf['username'], $db_conf['password']))) {
  die('Cannot connect to database: ' . mysql_error());
}
if (! ($dbselect = mysql_select_db($db_conf['database']))) {
  die('Cannot select database: ' . mysql_error());
}

$config = array();

$config['profile_id']="1";

$config['skin']="standard";

$config['server_tpl']=dirname(__FILE__)."/skins/".$config['skin'];

$config['emergency_contact']=$config['default_email'];

if (!file_exists(dirname(__FILE__)."/language/{$_COOKIE['use_language']}.php"))
{
$_COOKIE['use_language']=false;
}

$config['language']=($_COOKIE['use_language'])?$_COOKIE['use_language']:"en-us";

$config['hash']="649fe8359c71dc20b98df67aa5ee7c29";
?>