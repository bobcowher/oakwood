<?PHP
$e7d8519cd15377ed0c4313a338f2814a="78387d8ea7680a67ddb5a843a32b126a";

#-------------------------------------------------------------------------------------------------------------

include "autopilot_configuration.php";
include "inc/globals.php";
include "language/".$config['language'].".php";
include "inc/general_functions.php";
include "inc/order_functions.php";
include "inc/display_functions.php";
include "inc/domain_functions.php";
include "inc/whois_functions.php";

// set charset
$charset = acb_get_charset();
header("Content-type: text/html; charset={$charset}");

#-------------------------------------------------------------------------------------------------------------

if (!$c40181b59df275585740ecc344d3eb98) { die("Error[4]: Invalid file access, exiting..."); }
if (strlen($c40181b59df275585740ecc344d3eb98)!=32) { die("Error[5]: Invalid file access, exiting..."); }
if (strlen(${c40181b59df275585740ecc344d3eb98})!=32) { die("Error[6]: Invalid file access, exiting..."); }
if (strcmp($c40181b59df275585740ecc344d3eb98, "50d88f80f3f2c2329d15a78dbe59d259")!=0)
	{
	die("Error[7]: Invalid file access, exiting...");
	}

#-------------------------------------------------------------------------------------------------------------

if ($_COOKIE['order_session']) { $session=get_session_data($_COOKIE['order_session'], $config, $w); }

#-------------------------------------------------------------------------------------------------------------

$category=form_category(x( "category_id"));

if (x( "category_id"))
	{
	$query_string="?category_id=";
	$query_string.=x( "category_id");
	}

$view_cart="<img src='".$config['http_tpl_image']."/default[-1].gif' width='1' height='2' alt='spacer'>";
$view_cart.="<div class='but2' style='float: none;'><a href='".$config['http_web']."/view_cart.php".$query_string."' class='but2' style='float: none;'>";
$view_cart.="View Order";
$view_cart.="</a></div>";
$view_cart.="<img src='".$config['http_tpl_image']."/default[-1].gif' width='1' height='8' alt=''>";
$view_cart.="<br />";

$buy_now="<div class='but2' style='float: none;'><a href='".$config['http_web']."/checkout.php".$query_string."'>";
$buy_now.="Complete Order";
$buy_now.="</a></div>";
$buy_now.="<img src='".$config['http_tpl_image']."/default[-1].gif' width='1' height='2' alt='spacer'>";
$temp=$session;
unset($temp['notes']);
unset($temp['processor_key']);
if (!$temp) { $buy_now=""; }

$before="<img src='".$config['http_tpl_image']."/default[1].gif'>";

/*
$links_right="<div class='wrapper'><center>";
$links_right.=$view_cart;
$links_right.=$buy_now;
$links_right.="</center></div><br />";
*/

$links_right.="<div class='wrapper'>";
$links_right.="<span class='text_red_header'>".$w['browse_products']['categories']."</span><br />";
$links_right.="<img src='".$config['http_tpl_image']."/default[-1].gif' width='1' height='3'><br />";
$buy_domains=true;
$links_right.=format_category_links(get_category_links($category, 0), $before, "<br />\n");
$links_right.="</div>";

$product_array=get_product_array($category, x( "category_id"));
$buy_domains=true;

// [eric] 07/30/2006 - #84 Domain Search by GET Method
if ((isset($_GET['domain'])) && ($_GET['domain'] != '')) {
    $_POST['do_whois'] = 'true';
    $_POST['sld']      = $_GET['domain'];
}

$processor=unserialize($config['processor_array']);
$that=show_processor_names($processor);

include $config['server_tpl']."/header.php";
include $config['server_tpl']."/check_domain.php";
include $config['server_tpl']."/footer.php";
mysql_close($dblink);
?>