<?PHP
$e7d8519cd15377ed0c4313a338f2814a="78387d8ea7680a67ddb5a843a32b126a";

#-------------------------------------------------------------------------------------------------------------

include "autopilot_configuration.php";
include "inc/globals.php";
include "language/".$config['language'].".php";
include "inc/general_functions.php";
include "inc/login_functions.php";
include "includes/classes/forms.php";
include "includes/template_data/checkout.php";


#-------------------------------------------------------------------------------------------------------------

if (!$c40181b59df275585740ecc344d3eb98) { die("Error[4]: Invalid file access, exiting..."); }
if (strlen($c40181b59df275585740ecc344d3eb98)!=32) { die("Error[5]: Invalid file access, exiting..."); }
if (strlen(${c40181b59df275585740ecc344d3eb98})!=32) { die("Error[6]: Invalid file access, exiting..."); }
if (strcmp($c40181b59df275585740ecc344d3eb98, "50d88f80f3f2c2329d15a78dbe59d259")!=0)
	{
	die("Error[7]: Invalid file access, exiting...");
	}

#-------------------------------------------------------------------------------------------------------------

clear_cache();
$cookie_domain=get_cookie_domain($config);

#-------------------------------------------------------------------------------------------------------------

if ($_POST['resend'])
	{
	if (!$_POST['resend_email']) 
		{
		$resend_error="<span class='text_red_bold'>".$w['client_login']['error']['title']."</span> ";
		$resend_error.="<span class='text_red'>".$w['client_login']['error']['resend_email']."</span><br>"; 
		}

	$client_id=lookup_admin_by_email($_POST['resend_email']);
	if (!$client_id) 
		{
		$resend_error.="<span class='text_red_bold'>".$w['client_login']['error']['title']."</span> ";
		$resend_error.="<span class='text_red'>".$w['client_login']['error']['email_not_found']."</span><br>";
		}

	if (!$resend_error)
		{
		include "inc/email_functions.php";

		$password=random_password();
		update_with_random($_POST['resend_email'], $password);
		
		$query="select ";
		$query.="first_name, ";
		$query.="last_name ";
		$query.="from ";
		$query.="autopilot_clients ";
		$query.="where ";
		$query.="email='".a($_POST['resend_email'])."' ";
		$query.="limit 0, 1";

		$rs=mysql_fetch_row(mysql_query($query));

		$array['event_id']="client_resend_password";
		$array['to_email']=$_POST['resend_email'];
		$array['to_name']=sx($rs[0])." ".sx($rs[1]);
		$array['config']=$config;

		compile_email($array);

		unset($password);
		unset($_POST['resend_email']);

		$resend_success="<span class='text_green_bold'>".$w['client_login']['success']['title']."</span> ";
		$resend_success.="<span class='text_green'>".$w['client_login']['success']['password_emailed']."</span><br>";

		@setcookie("autopilot_clients_session", "", (time()-31104000), "/", $cookie_domain);
		@setcookie("autopilot_remember_me", "", (time()-31104000), "/", $cookie_domain);
		}
	}

if ($_POST['login'])
	{
	if (!$_POST['login_email']) 
		{
		$login_error.="<span class='text_red_bold'>".$w['client_login']['error']['title']."</span> ";
		$login_error.="<span class='text_red'>".$w['client_login']['error']['no_email']."</span><br>"; 
		}
	
	$client_id=lookup_admin_by_email($_POST['login_email']);
	if (!$client_id) 
		{
		$login_error.="<span class='text_red_bold'>".$w['client_login']['error']['title']."</span> ";
		$login_error.="<span class='text_red'>".$w['client_login']['error']['email_not_found']."</span><br>";
		}

	if (!$_POST['login_password']) 
		{
		$login_error.="<span class='text_red_bold'>".$w['client_login']['error']['title']."</span> ";
		$login_error.="<span class='text_red'>".$w['client_login']['error']['no_password']."</span><br>"; 
		}
	
	$client_session=lookup_admin($_POST['login_email'], $_POST['login_password']);
	if (!$client_session) 
		{
		$login_error.="<span class='text_red_bold'>".$w['checkout']['error']['title']."</span> ";
		$login_error.="<span class='text_red'>".$w['checkout']['error']['login_failed']."</span><br>";
		}

	if (!$login_error)
		{
		$login_error="<span class='text_red_bold'>".$w['client_login']['error']['title']."</span> ";
		$login_error.="<span class='text_red'>".$w['client_login']['error']['db_failed']."</span><br>";
		
		$client_session=session_create_by_client_id($client_session, $_SERVER);
		if ($client_session)
			{
			@setcookie("client_session", "", (time()-31104000), "/", $cookie_domain);
			@setcookie("client_session", $client_session, (time()+31104000), "/", $cookie_domain);
			@setcookie("use_language", $_POST['use_language'], (time()+31104000), "/", $cookie_domain);
			
			header("Location: ".$config['http_web']."/client_area.php");
			exit;
			}
		}

	unset($client_session);

	@setcookie("client_session", "", (time()-31104000), "/", $cookie_domain);
	}

include $config['server_tpl']."/header.php";
include $config['server_tpl']."/client_login.php";
include $config['server_tpl']."/footer.php";
mysql_close($dblink); 
?>