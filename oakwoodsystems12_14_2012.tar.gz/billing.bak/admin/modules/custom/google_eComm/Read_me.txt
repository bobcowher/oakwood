1. Upload the admin package to the modules/custom/iDev Affiliate folder in the admin area, if it's not there, create it
2. Follow the directions below:

Admin Login -> Configuration graphic -> Custom Modules -> Add New Module

Then:
Menu Title = iDev Affiliate
History Label = iDev Affiliate
Module Runtime = Module runs in the order system after payment
If Order, Available to Profiles = Check the box for the order system in which you want the module to run

3. Open up the client side module file module_start.php in your favorit text editor, you will need to MANUALLY configure this file.

4. Finally, you will also need to upload the order system iDev Affiliate module for each order system you've checked to the modules/custom/iDev Affiliate folder, if it's not there, create it