<?PHP
$e7d8519cd15377ed0c4313a338f2814a="78387d8ea7680a67ddb5a843a32b126a";

#-------------------------------------------------------------------------------------------------------------

include "autopilot_configuration.php";
include "inc/globals.php";
include "language/".$config['language'].".php";
include "inc/general_functions.php";
include "inc/order_functions.php";
include "inc/display_functions.php";
include "inc/login_functions.php";
include "inc/client_functions.php";
include "inc/server_functions.php";
include "inc/billing_functions.php";

// set charset
$charset = acb_get_charset();
header("Content-type: text/html; charset={$charset}");
$invoice_payment=$_POST['invoice_payment'];

#-------------------------------------------------------------------------------------------------------------

if (!$c40181b59df275585740ecc344d3eb98) { die("Error[4]: Invalid file access, exiting..."); }
if (strlen($c40181b59df275585740ecc344d3eb98)!=32) { die("Error[5]: Invalid file access, exiting..."); }
if (strlen(${c40181b59df275585740ecc344d3eb98})!=32) { die("Error[6]: Invalid file access, exiting..."); }
if (strcmp($c40181b59df275585740ecc344d3eb98, "50d88f80f3f2c2329d15a78dbe59d259")!=0)
	{
	die("Error[7]: Invalid file access, exiting...");
	}

#-------------------------------------------------------------------------------------------------------------

$cookie_domain=get_cookie_domain($config);

#-------------------------------------------------------------------------------------------------------------

if ($_COOKIE['order_session']) { $session=get_session_data($_COOKIE['order_session'], $config, $w); }

#-------------------------------------------------------------------------------------------------------------

$client=get_client_details($_COOKIE['client_session']);
if (!$client)
	{
	@setcookie("client_session", "", (time()+31536000), "/", $cookie_domain);
	header("Location: ".$config['http_web']."/verify_order.php");
	exit;
	}

#-------------------------------------------------------------------------------------------------------------

$cc=get_cc_data($client['client_id']);
$cc_ending_in=substr($cc['card_number'], -4);

#-------------------------------------------------------------------------------------------------------------

if (x("cart_id")) { $cart_id=x("cart_id"); }
else { $cart_id=billing_create_cart_id_order($_COOKIE['order_session']); }
$id_set=get_id_set_read_only($cart_id);

$_invTotal = billing_register_balance("cart_id = '{$cart_id}'");

if ($_invTotal{0} == '-') $_invTotal = substr($_invTotal, 1);

$total = array('sub_total'  => $_invTotal,
               'tax_total'  => 0,
               'total_due'  => $_invTotal);
               
#-------------------------------------------------------------------------------------------------------------

if (x("processor_key")) { $session['processor_key']=x("processor_key"); }
$processor_general=get_processor_general($session['processor_key']);
$processor_specific=get_processor_specific($session['processor_key']);

#-------------------------------------------------------------------------------------------------------------

# 030480dc3540a214a4f9bf5925760c8a <--- offline processor_key
$offline_processors=array("030480dc3540a214a4f9bf5925760c8a");

#-------------------------------------------------------------------------------------------------------------

if ($_POST['do_this']=="old_card")
	{
	$custom=$_COOKIE['order_session']."+";
	$custom.=$session['processor_key']."+";
	$custom.=implode("+", $id_set['order_id']);

	$cc_data['first_name']=$client['first_name'];
	$cc_data['last_name']=$client['last_name'];
	$cc_data['address_1']=$client['address_1'];
	$cc_data['city']=$client['city'];
	$cc_data['state']=$client['state'];
	$cc_data['zip']=$client['zip'];
	$cc_data['country']=$client['country'];
	$cc_data['phone']=$client['phone'];
	$cc_data['fax']=$client['fax'];
	$cc_data['email']=$client['email'];
	$cc_data['card_number']=$cc['card_number'];
	$cc_data['card_expires_month']=$cc['card_expires_month'];
	$cc_data['card_expires_year']=$cc['card_expires_year'];
	# $cc_data['cvv2']=$_POST['cvv2'];
	$cc_data['cvv2']="";
	$cc_data['invoice_payment']=$invoice_payment;
	
	$_POST = array_merge($_POST, $cc_data); // fix for "credit card number required"

	if (!$processor_general['return_file'] || $processor_general['return_file'] == '') {
	   // try to guess the filename
	   $processor_general['return_file'] = str_replace('-admin.', '-return.', $processor_general['admin_file']);
	}

	include "modules/processor/".$processor_general['return_file'];
	}
else if ($_POST['do_this']=="new_card")
	{
	if (!$_POST['first_name'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['first_name']."</span><br>";
		}

	if (!$_POST['last_name'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['last_name']."</span><br>";
		}

	if (!$_POST['address_1'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['address']."</span><br>";
		}

	if (!$_POST['city'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['city']."</span><br>";
		}

	if (!$_POST['state']&&!$_POST['province'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['state']."</span><br>";
		}

	if (!$_POST['zip'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['zip']."</span><br>";
		}

	if (!$_POST['country'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['enter_country']."</span><br>";
		}

	if (!$_POST['phone'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['enter_phone']."</span><br>";
		}

	if (!$_POST['email'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['please_enter_email']."</span><br>";
		}

	if ($_POST['do_this']=="new_card"&&!$_POST['card_number'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['card_number']."</span><br>";
		}

	if ($_POST['do_this']=="new_card"&&!$_POST['card_expires_month'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['card_expires_month']."</span><br>";
		}

	if ($_POST['do_this']=="new_card"&&!$_POST['card_expires_year'])
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['card_expires_year']."</span><br>";
		}

	if ($_POST['do_this']=="new_card"
		&&!$_POST['cvv2']
		&&!in_array($processor_general['processor_key'], $offline_processors))
		{
		$error.="&nbsp;&nbsp;<span class='text_red_bold'>".$w['credit_card']['error']['title']."</span> ";
		$error.="<span class='text_red'>".$w['credit_card']['error']['cvv2']."</span><br>";
		}

	if (!$error)
		{
		$_POST['client_id']=$client['client_id'];
		update_cc_data($_POST);

		$custom=$_COOKIE['order_session']."+";
		$custom.=$session['processor_key']."+";
		$custom.=@implode("+", $id_set['order_id']);

		$cc_data['first_name']=$_POST['first_name'];
		$cc_data['last_name']=$_POST['last_name'];
		$cc_data['address_1']=$_POST['address_1'];
		$cc_data['city']=$_POST['city'];
		$cc_data['state']=$_POST['state'];
		$cc_data['zip']=$_POST['zip'];
		$cc_data['country']=$_POST['country'];
		$cc_data['phone']=$_POST['phone'];
		$cc_data['fax']=$_POST['fax'];
		$cc_data['email']=$_POST['email'];
		$cc_data['card_number']=$_POST['card_number'];
		$cc_data['expire_date']=$_POST['card_expires_month'].$_POST['card_expires_year'];
		$cc_data['cvv2']=$_POST['cvv2'];
		$cc_data['invoice_payment']=$invoice_payment;

		if (!$processor_general['return_file'] || $processor_general['return_file'] == '') {
    	   // try to guess the filename
    	   $processor_general['return_file'] = str_replace('-admin.', '-return.', $processor_general['admin_file']);
    	}

		include "modules/processor/".$processor_general['return_file'];
		}
	}

#-------------------------------------------------------------------------------------------------------------

include $config['server_tpl']."/header.php";
include $config['server_tpl']."/credit_card.php";
include $config['server_tpl']."/footer.php";
mysql_close($dblink);
?>