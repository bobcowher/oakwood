<?php
$db_conf = array(
  'hostname' => 'localhost',
  'username' => 'whm_auto',
  'password' => 'Ch8fRef5',
  'database' => 'whm_auto',
);
if (! ($dblink = mysql_connect($db_conf['hostname'], $db_conf['username'], $db_conf['password']))) {
  die('Cannot connect to database: ' . mysql_error());
}
if (! ($dbselect = mysql_select_db($db_conf['database']))) {
  die('Cannot select database: ' . mysql_error());
}
